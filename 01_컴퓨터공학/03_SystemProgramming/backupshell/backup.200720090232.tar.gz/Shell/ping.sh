#!/bin/bash

ping -c 1 192.168.0.11> /dev/null

if [ $? == 0 ]
then
	echo "gateway ping is successed!!"
else
	echo "geteway ping is failed"
fi	
