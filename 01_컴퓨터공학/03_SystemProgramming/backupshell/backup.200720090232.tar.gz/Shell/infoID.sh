#!/bin/bash

my_name='minhee Kang'
my_age='30'
my_job="programmer"

echo $my_name
echo $my_age
echo $my_job

echo $my_name $my_age $my_job


