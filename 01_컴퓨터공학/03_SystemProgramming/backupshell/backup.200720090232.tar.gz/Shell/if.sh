#!/bin/bash

if [ $1 != $2 ]
then
	echo "different values"
	exit
fi


