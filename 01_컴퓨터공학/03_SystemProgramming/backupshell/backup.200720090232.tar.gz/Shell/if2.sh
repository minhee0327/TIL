#!/bin/bash

if [ $1 -gt $2 ] 
then
	echo "$1 is larger than $2"
	exit
fi
