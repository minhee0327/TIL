#!/bin/bash

if [ $1 == $2 ]
then
	echo 'same values'
	exit
else
	echo 'different values'
	exit
fi

