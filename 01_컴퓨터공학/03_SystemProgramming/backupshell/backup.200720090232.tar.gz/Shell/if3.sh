#!/bin/bash

if [ -e $1 ] 
then
	echo "The file exists"
	exit
else
	echo "The file doesn't exists"
	exit
fi


	
