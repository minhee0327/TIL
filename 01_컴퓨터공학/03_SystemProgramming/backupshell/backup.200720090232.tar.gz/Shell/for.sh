#!/bin/bash

for database in $(ls)
do
	echo $database
done
