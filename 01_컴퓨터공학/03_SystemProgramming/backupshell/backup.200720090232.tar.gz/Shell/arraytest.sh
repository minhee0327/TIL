#!/bin/bash

lst=("minhee Kang" 30 "programmer")

echo ${lst[@]} 
echo ${lst[*]}
echo ${lst[2]}
echo ${#lst[*]}
