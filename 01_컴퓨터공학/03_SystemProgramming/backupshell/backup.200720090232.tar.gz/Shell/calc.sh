#!/bin/bash

num=`expr \( 10 + 20 \) / 8 - 8`

echo $num

